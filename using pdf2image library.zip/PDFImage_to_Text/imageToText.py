'''
###############Developed by Deepak Lohia at www.dlohia.com###############

STEP1> install Anaconda
STEP2> Launch VS Via Anaconda and install libraries (as required)

conda install -c conda-forge poppler
conda install conda-forge::pdf2image
conda install conda-forge/label/cf202003::pdf2image
conda install conda-forge::pytesseract
conda install conda-forge/label/cf202003::pytesseract
conda install -c anaconda glob2 (if you are using pdf folder)

STEP3: Download Popper from https://github.com/oschwartz10612/poppler-windows
Extract and save in a location and update Poppler path in Python Script (imageToText.py)

STEP4: Update output(for Text) and input path (for PDF) in the Python Script.(imageToText.py )
STEP5: Run the script , ensure that you have "Anaconda" as interpreter which is auto updated when we open Visual Studio via Anaconda.
'''
import pytesseract
from pdf2image import convert_from_path
import glob

input_pdfs = glob.glob(r'C:\Users\dell\Downloads\input_pdf\*.pdf')
output_path = r'C:\Users\dell\Downloads\output_text'
poppler_path= r'C:\Users\dell\Documents\Python\PDFImage_to_Text\Poppler\poppler-24.07.0\Library\bin'
fileCount = 0
print('Process Started...')

for pdf_path in input_pdfs:
    fileCount +=1
    pages = convert_from_path(pdf_path,  500,  poppler_path)
    print(f'Extracting...{pdf_path}')
    
    for pageNum,imgBlob in enumerate(pages):
        text = pytesseract.image_to_string(imgBlob,lang='eng')
        
        outputPath =f'{output_path}\\PDF_page{pageNum}.txt'
        with open(outputPath, 'w') as the_file:
            the_file.write(text)
            print(f'Extracted at...{outputPath}')

print('Process Done')
if (fileCount == 0):
    print(f'{output_path}-No PDF Files found, ensure that PDF folder path is correct')